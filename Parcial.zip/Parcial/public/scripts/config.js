module.exports = {
    secret : 'secretkey',
    port: 3000
}